package starter;

/**
 * This class is here to identify the type of entity,
 * There maybe some redundancy here as I have already allocated an 
 * entire class to just the player.  
 */ 

public enum Id {
	player,
	enemy,
	immovable;
}
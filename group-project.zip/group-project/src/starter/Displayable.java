package starter;

public interface Displayable {
	public void showContents();
	public void hideContents();
}
